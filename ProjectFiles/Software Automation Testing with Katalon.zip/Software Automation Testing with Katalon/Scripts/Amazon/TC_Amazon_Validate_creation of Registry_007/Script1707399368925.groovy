import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.amazon.com/')

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon.com/input_field-keywords'), 'YLUUYP')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon.com/button_Continue shopping'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon.com. Spend less. Smile more/input_a-button-input'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon.com. Spend less. Smile more/a_Registry'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon Registry  Gifting/a_Create a registry or gift list'))

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon Sign-In/input_email'), '+91 8333850525')

WebUI.setEncryptedText(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon Sign-In/input_password'), 
    'gnJRfLEd4AELu0dUXJgQTQ==')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon Sign-In/inputsignInSubmit'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Amazon Registry  Gifting/span_Celebrating a birthday'))

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/inputfirstAndLastName'), 
    'Andavarapu Pavan Kalyan')

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/input_gr-create-flow-input-field giftListName'), 
    'Birthday Gift')

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/inputgr-creation-flow-event-date'), 
    '')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/inputgr-creation-flow-event-date'))

WebUI.doubleClick(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/a_Show April 2024'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/a_16'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/span_State'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/input_a-button-input'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/span_State'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/a_AL'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/input_a-button-input'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/input_a-button-input'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/input_a-button-input'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_Registry_OR/Page_Create a Gift List - Amazon Registry  Gifting/input_a-button-input'))

WebUI.closeBrowser()

