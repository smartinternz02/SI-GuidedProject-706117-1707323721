<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Celebrating a birthday</name>
   <tag></tag>
   <elementGuidId>2d428f90-68c2-4fb1-baf0-c4641356f990</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div[2]/div/div/a[3]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6b524442-33fa-4958-86bb-e367ad14558d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-base gr-registry-types__header</value>
      <webElementGuid>d1772a19-8032-4d9f-8875-f96d54d1bc74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Celebrating a birthday
        </value>
      <webElementGuid>f0b8500b-8a56-49f1-b04b-44ad81c0a5cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;gr&quot;]/div[@class=&quot;gr__container&quot;]/div[@class=&quot;a-section gr-registry-types&quot;]/a[@class=&quot;a-link-normal gr-registry-types__card&quot;]/span[@class=&quot;a-size-base gr-registry-types__header&quot;]</value>
      <webElementGuid>ad8daebe-2e72-4e26-b1b5-f721ac6845a1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div[2]/div/div/a[3]/span</value>
      <webElementGuid>35f23f7c-57b0-4791-923e-0334acd93e50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/a[3]/span</value>
      <webElementGuid>2836bac0-a4aa-4326-807f-d54e77fcc0af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            Celebrating a birthday
        ' or . = '
            Celebrating a birthday
        ')]</value>
      <webElementGuid>ca27b38d-2a4b-4b09-8fc9-006fb915c3e0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
