<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DDT_Amazon_Category Validation_Testsuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>8b21b83e-f404-4f3b-a65f-5932604a53af</testSuiteGuid>
   <testCaseLink>
      <guid>30eae89c-2acc-4a3c-aedc-45849eb565db</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data_Driven_Testing/TC_Validation_Amazon_Category_Excel</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>e931cc4c-c9e0-4760-a589-cadf71b3833a</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_TestData/Amazon_TestData_excel</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>e931cc4c-c9e0-4760-a589-cadf71b3833a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Category</value>
         <variableId>385f14d2-6659-4745-b0c7-8850c955b076</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>e931cc4c-c9e0-4760-a589-cadf71b3833a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Item</value>
         <variableId>525f3d85-f732-4be8-ad64-a27b5cceb4f8</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
